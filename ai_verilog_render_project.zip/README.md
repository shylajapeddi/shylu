# AI Verilog Coding Workflow

Browser-based AI Verilog generator/tester using Gemini, LangGraph and Icarus Verilog.

## Render
Add environment variable:
`GEMINI_API_KEY` = your Gemini API key.

This repository includes a Dockerfile. Deploy it as a Render Web Service using Docker.

The container starts with:
`gunicorn --bind 0.0.0.0:10000 --workers 1 --timeout 120 app:app`

Do not upload your API key to GitHub.

## Local
`pip install -r requirements.txt`
Set `GEMINI_API_KEY`, then run `python app.py`.
